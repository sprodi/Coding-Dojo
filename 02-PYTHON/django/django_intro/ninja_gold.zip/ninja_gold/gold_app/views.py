from django.shortcuts import render, redirect
from random import randint
from time import gmtime, strftime


# Create your views here.
def ninja_gold(request):
   if 'count' not in request.session:
      request.session['count'] = 0
   context = {
      'date': strftime("%Y/%m/%d", gmtime()),
      'time': strftime("%I:%M %p", gmtime()),
   }
   return render(request, 'index.html', context)

def farm(request):
   if 'count' not in request.session:
      request.session['count'] = 0
   request.session['gold'] = randint(10, 20)
   print(request.session['gold'])
   return redirect('/process_money')

def cave(request):
   if 'count' not in request.session:
      request.session['count'] = 0
   request.session['gold'] = randint(5, 10)
   print(request.session['gold'])
   return redirect('/process_money')

def house(request):
   if 'count' not in request.session:
      request.session['count'] = 0
   request.session['gold'] = randint(2, 5)
   print(request.session['gold'])
   return redirect('/process_money')     

def casino(request):
   if 'count' not in request.session:
      request.session['count'] = 0
   request.session['gold'] = randint(-50, 50)
   print(request.session['gold'])
   return redirect('/process_money')     

def process_money(request):
   request.session['count'] += request.session['gold']
   if request.method == 'GET':
      return redirect('/')
   return render(request, 'index.html')


def reset(request):
   request.session.flush()
   return redirect('/ninja_gold')