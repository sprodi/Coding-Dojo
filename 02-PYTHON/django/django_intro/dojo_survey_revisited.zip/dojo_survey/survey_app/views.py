from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):
   return render(request,'index.html')

def form_request(request):
   print(request.POST)
   if request.method == 'GET':
      return redirect('/')
   request.session['name'] = request.POST['name']
   request.session['gender'] = request.POST['gender']
   request.session['location'] = request.POST['location']
   request.session['fav_lang'] = request.POST['fav_lang']
   request.session['comment'] = request.POST['comment']
   return redirect('/form_result')

def form_result(request):
   return render(request, 'results.html')