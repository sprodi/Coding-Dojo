from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('results', views.form_request),
    path('form_result', views.form_result),
]