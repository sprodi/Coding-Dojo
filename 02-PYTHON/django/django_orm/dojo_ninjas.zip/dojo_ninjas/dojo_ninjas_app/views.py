from django.shortcuts import render, redirect
from .models import Dojos, Ninjas

# Create your views here.
def index(request):
   context = {
      'dojos': Dojos.objects.all(),
      'ninjas': Ninjas.objects.all(),
      'count': 0,
   }
   return render(request, 'index.html', context)

def create_dojo(request):
   Dojos.objects.create(
      name = request.POST['name'],
      city = request.POST['city'],
      state = request.POST['state'],
      )
   return redirect('/')

def delete_dojo(request, dojo_id):
   dojo_to_delete = Dojos.objects.get(id = dojo_id)
   dojo_to_delete.delete()
   return redirect('/')

def create_ninja(request):
   Ninjas.objects.create(
      first_name = request.POST['first_name'],
      last_name = request.POST['last_name'],
      dojo_id = request.POST['dojo'],
      )
   return redirect('/')

def delete_ninja(request, ninja_id):
   ninja_to_delete = Ninjas.objects.get(id = ninja_id)
   ninja_to_delete.delete()
   return redirect('/')