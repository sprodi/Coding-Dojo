from django.urls import path
from . import views

urlpatterns = [
   path('', views.index),
   path('books/create', views.create_book),
   path('books/<int:book_id>', views.book),
   path('books/<int:book_id>/add_author', views.add_author_to_book),
   path('books/<int:book_id>/delete', views.delete_book),
   path('authors', views.authors),
   path('authors/create', views.create_authors),
   path('authors/<int:author_id>', views.profile_author),
   path('authors/<int:author_id>/add_book', views.add_book_to_author),
   path('authors/<int:author_id>/delete', views.delete_author),
]
