from django.urls import path
from . import views

urlpatterns = [
    path('', views.wall),
    path('create', views.create_message),
    path('post_comment/<int:id>', views.post_comment),
    path('delete_comment/<int:id>', views.delete_comment),
]
