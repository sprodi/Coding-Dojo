from django.shortcuts import render, redirect, HttpResponse
from .models import *
from django.contrib import messages

# Create your views here.
def wall(request):
   if 'user_id' not in request.session:
      return redirect('/')
   user = User.objects.get(id=request.session['user_id'])
   context = {
      'user': user,
      'wall_messages': Wall_Message.objects.all(),
   }
   return render(request, 'wall.html', context)

def create_message(request):
   print(request.POST)
   errors = Wall_Message.objects.basic_validator(request.POST)
   if errors:
      for k, v in errors.items():
         messages.error(request, v)
      return redirect('/wall')
   else:
      Wall_Message.objects.create(
         message = request.POST['msg'],
         poster = User.objects.get(id=request.session['user_id'])
      )
   return redirect('/wall')

def post_comment(request, id):
   print(request.POST)
   print(request.POST['comment'])
   poster = User.objects.get(id=request.session['user_id'])
   message = Wall_Message.objects.get(id=id)
   errors = Comment.objects.basic_validator(request.POST)
   if errors:
      for k, v in errors.items():
         messages.error(request, v)
      return redirect('/wall')
   else:
      Comment.objects.create(
         comment = request.POST['comment'],
         poster = poster,
         wall_message = message
         )
   return redirect('/wall')

def delete_comment(request, id):
    destroyed = Comment.objects.get(id=id)
    destroyed.delete()
    return redirect('/wall')