from django.db import models
from login_app.models import User

class MessageManager(models.Manager):
   def basic_validator(self, post_data):
      errors = {}

      if len(post_data['msg']) < 5:
         errors['msg'] = "Message must be at least 5 characters long."
      return errors

class CommentManager(models.Manager):
   def basic_validator(self, post_data):
      errors = {}

      if len(post_data['comment']) < 1:
         errors['comment'] = "Comment must be at least 1 character long."
      return errors

class Wall_Message(models.Model):
   message = models.CharField(max_length=255)
   poster = models.ForeignKey(User, related_name='user_messages', on_delete=models.CASCADE)
   created_at = models.DateTimeField(auto_now_add = True)
   update_at = models.DateTimeField(auto_now = True)
   objects = MessageManager()

class Comment(models.Model):
   comment = models.CharField(max_length=255)
   poster = models.ForeignKey(User, related_name='user_comments', on_delete=models.CASCADE)
   wall_message = models.ForeignKey(Wall_Message, related_name="post_comments", on_delete=models.CASCADE)
   created_at = models.DateTimeField(auto_now_add = True)
   update_at = models.DateTimeField(auto_now = True)  
   objects = CommentManager()

