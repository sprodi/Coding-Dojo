from django.db import models
import re
import bcrypt

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
# Create your models here.
class UserManager(models.Manager):
   def basic_validator(self, post_data):
      # run validate here
      # fname lname at least 2 char user_login
      # email valid
      # pw should match
      # pw at least 8 char long
      errors = {}

      if len(post_data['fname']) < 2:
         errors['fname'] = "First name must be at least two characters long."
      if len(post_data['lname']) < 2:
         errors['lname'] = "Last name must be at least two characters long."
      if not EMAIL_REGEX.match(post_data['email']):          
         errors['email'] = ("Invalid email address.")
      if len(post_data['password']) < 8:
         errors['password'] = "Password must be at least eight characters long."
      if post_data['password'] != post_data['confirm']:
         errors['password'] = 'Passwords do not match'
      return errors

   def authenticate(self, email, password):
      users = self.filter(email=email)
      if not users:
         return False

      user = users[0]
      return bcrypt.checkpw(password.encode(), user.password.encode())

   def register(self, form):
      pw = bcrypt.hashpw(form['password'].encode(), bcrypt.gensalt()).decode()
      return self.create(
         fname = form['fname'],
         lname = form['lname'],
         email = form['email'],
         password = pw,
      )  

class User(models.Model):
   fname = models.CharField(max_length = 50)
   lname = models.CharField(max_length = 50)
   email = models.CharField(max_length = 50)
   password = models.CharField(max_length = 50)
   confirm_pw = models.CharField(max_length = 50)
   created_at = models.DateTimeField(auto_now_add = True)
   update_at = models.DateTimeField(auto_now = True)
   objects = UserManager()