from django.shortcuts import render, redirect, HttpResponse
from .models import User
from django.contrib import messages

# Create your views here.
def index(request):
   context = {
      'users': User.objects.all()
   }
   return render(request, 'index.html', context)

def register(request):
   if request.method == 'GET':
      return redirect('/')
   errors = User.objects.basic_validator(request.POST)
   if errors:
      for k, v in errors.items():
         messages.error(request, v)
      return redirect('/')
   else:
      new_user = User.objects.register(request.POST)
      request.session['user_id'] = new_user.id
      messages.success(request, "You have successfuly registered!")
      return redirect('/success')
   return redirect('/')

def login(request):
   if request.method == "GET":
      return redirect('/')
   if not User.objects.authenticate(request.POST['email'], request.POST['password']):
      messages.error(request, 'Invalid Email/Password')
      return redirect('/')
   user = User.objects.get(email=request.POST['email'])
   request.session['user_id'] = user.id
   messages.success(request, "You have successfully logged in!")
   return redirect('/books')

def logout(request):
    request.session.clear()
    return redirect('/')

def success(request):
   if 'user_id' not in request.session:
      return redirect('/')
   messages.success(request, "You have successfully logged in!")
   return redirect('/books')