from django.shortcuts import render, redirect, HttpResponse
from .models import *
from django.contrib import messages

# Create your views here.
def books(request):
   # return HttpResponse('Books')
   user = User.objects.get(id=request.session['user_id'])
   context = {
      'user': user,
      'books': Book.objects.all(),
   }
   return render(request, 'books.html', context)

def create_book(request):
   print(request.POST)
   errors = Book.objects.basic_validator(request.POST)
   if errors:
      for k, v in errors.items():
         messages.error(request, v)
      return redirect('/books')
   else:
      user = User.objects.get(id=request.session['user_id'])
      book = Book.objects.create(
         title = request.POST['title'],
         desc = request.POST['desc'],
         uploaded_by = user
      )
      user.liked_books.add(book)
   return redirect('/books')

def book(request, book_id):
   print(request.POST)
   if "user_id" not in request.session:
      return redirect('/')
   else:
      context = {
         'book': Book.objects.get(id = book_id),
         'user': User.objects.get(id=request.session['user_id'])
      }
      return render(request, 'view_book.html', context)

def edit_book(request, book_id):
   book_to_edit = Book.objects.get(id = book_id)
   context = {
      'book': book_to_edit
   }
   return render(request, 'edit_book.html', context)

def update_book(request, book_id):
   errors = Book.objects.basic_validator(request.POST)
   if errors:
      for k, v in errors.items():
         messages.error(request, v)
      return redirect(f'/book/{book_id}')
   else:
      book_to_update = Book.objects.get(id = book_id)
      book_to_update.title = request.POST["title"]
      book_to_update.desc = request.POST["desc"]
      book_to_update.save()
      return redirect('/books')

def delete_book(request, book_id):
   book = Book.objects.get(id=book_id)
   book.delete()
   return redirect('/books')
   # return render(request, 'books.html', context)

def favorite(request, book_id):
   user = User.objects.get(id=request.session['user_id'])
   book = Book.objects.get(id=book_id)
   user.liked_books.add(book)
   return redirect('/books')

def unfavorite(request, book_id):
   user = User.objects.get(id=request.session['user_id'])
   book = Book.objects.get(id=book_id)
   user.liked_books.remove(book)
   return redirect('/books')
