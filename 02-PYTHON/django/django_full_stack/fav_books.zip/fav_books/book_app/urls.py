from django.urls import path
from . import views

urlpatterns = [
    path('', views.books),
    path('create', views.create_book),
    path('<int:book_id>', views.book),
    path('<int:book_id>/update', views.update_book),
    path('<int:book_id>/destroy', views.delete_book),
    path('fav/<int:book_id>', views.favorite),
    path('unfav/<int:book_id>', views.unfavorite)
]