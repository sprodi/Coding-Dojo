from django.db import models

# Create your models here.
class CourseManager(models.Manager):

    def basic_validator(self, post_data):
        errors = {}

        if len(post_data['name']) < 5:
            errors['name'] = "Name must be at least five characters long."
        if len(post_data['name']) > 50:
            errors['name'] = "Name must be less than fifty characters long."
        if len(post_data['desc']) < 15:
            errors['desc'] = "Description must be at least fifteen character long."
        if len(post_data['desc']) > 250:
            errors['desc'] = "Description must be less than 250 characters long."
        return errors


class Course(models.Model):
   name = models.CharField(max_length = 50)
   desc = models.TextField()
   created_at = models.DateTimeField(auto_now_add = True)
   updated_at = models.DateTimeField(auto_now = True)
   objects = CourseManager()