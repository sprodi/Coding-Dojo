from django.shortcuts import render, redirect
from .models import Course
from django.contrib import messages

# Create your views here.
def index(request):
   context = {
      'courses': Course.objects.all()
   }
   return render(request, 'index.html', context)
   
def new_course(request):
   context = {
      'courses': Course.objects.all()
   }
   return redirect('/', context)

def create_course(request):
   errors = Course.objects.basic_validator(request.POST)
   if errors:
      for k, v in errors.items():
         messages.error(request, v)
      return redirect('/')
   else:
      Course.objects.create(
         name = request.POST['name'],
         desc = request.POST['desc'],
         )
      return redirect('/')

def delete_course(request, course_id):
   course_to_delete = Course.objects.get(id = course_id)
   context = {
      'course': Course.objects.get(id = course_id)
   }
   return render(request, 'delete.html', context)

def delete_confirmation(request, course_id):
   course_to_delete = Course.objects.get(id = course_id)
   course_to_delete.delete()
   return redirect('/')